SRIKANTH GAJJALA PORTFOLIO
==========================
Files:
- index.html
- styles.css
- script.js

Open index.html in a browser to preview locally.

To publish:
1. Upload these files to any static hosting provider.
2. Connect your custom domain.
3. Update the contact details or placement cards in index.html as needed.

Content basis:
- User-provided resume (uploaded in conversation)
- User-provided recent placement highlights
